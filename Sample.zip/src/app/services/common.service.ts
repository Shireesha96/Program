import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  loginUser:any=[{
      userid : 'vijay',
      password :'vijay123'
  }]

  constructor() { }
  onSubmit(user)
  {
    console.log(user);
   
    return this.loginUser;
  }
}
