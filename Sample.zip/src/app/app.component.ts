import { Component } from '@angular/core';
import {CommonService} from '../app/services/common.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent{
constructor(private serv: CommonService)
{
}
  title = 'Login'
  loginUser:any=[{
      userid : '',
      password :''
  }]

login(loginUser)
{
this.serv.onSubmit(loginUser).subscribe(data=>{
  alert(data);
})
};



}


